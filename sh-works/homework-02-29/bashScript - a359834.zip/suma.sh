#!/bin/bash
# 8

echo "$(( $1 + $2 ))"