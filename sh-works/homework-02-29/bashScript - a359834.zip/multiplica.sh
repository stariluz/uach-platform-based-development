#!/bin/bash
# 9

echo "$(( $1 * $2 ))"