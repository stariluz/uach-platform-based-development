#!/bin/bash
# 2

for(( i=0; i<40; i++ )); do
    touch "~/$i.log"
done